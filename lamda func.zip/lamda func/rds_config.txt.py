#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "group1pass"
db_name = "post-office"